﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _20._102k_Plahotnyy_2.Entity;

namespace _20._102k_Plahotnyy_2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            /*var query = Helper.GetContext().Teachers.ToList();*/
            var query = from Teachers in Helper.GetContext().Teachers
                        select new
                        {
                            Teachers.IdTeachers,
                            Teachers.LastName,
                            Teachers.FirstName,
                            Teachers.Patronymic,
                            Teachers.Email,
                            Teachers.IdStatusTeachers,
                            Teachers.IdRole,
                            Teachers.IdSpeciality
                        };
            LoadData.ItemsSource = query.ToList();

        }

        private void btn_search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var res = Helper.GetContext().Teachers.Where(p => p.Speciality.Title == "09.02.07 Информационные системы и программирование").OrderBy(p => p.LastName);
                var colv = Helper.GetContext().Teachers.Where(p => p.Speciality.Title == "09.02.07 Информационные системы и программирование").Count();
                LoadData.ItemsSource = res.ToList();
                if (colv <=0)
                {
                    MessageBox.Show("Отсутствуют");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Произошла неизвестная ошибка");
                throw;
            }
        }
    }
}
