﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20._102k_Plahotnyy_2
{
    class Helper
    {
        private static Entity.Entities entity;

        public static Entity.Entities GetContext()
        {
            if (entity == null)
            {
                entity = new Entity.Entities();
            }
            return entity;
        }
    }
}
